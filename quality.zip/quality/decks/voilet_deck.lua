
SMODS.Back {
    key = 'voilet_deck',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            all_blinds_size0 = 3
        },
    },
    loc_txt = {
        name = 'Voilet Deck',
        text = {
            [1] = '{C:attention}Quality{} Jokers may appear in the shop',
            [2] = 'Start with a {C:blue}Refined {}{C:attention}Quality{} Joker and {C:red}+1{} Discard',
            [3] = '{C:red}X3{} base Blind size'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.GAME.starting_params.discards = G.GAME.starting_params.discards + 1
        G.E_MANAGER:add_event(Event({
            func = function()
                play_sound('timpani')
                if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                    G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                    local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_quality_jokerR' })
                    if new_joker then
                    end
                    G.GAME.joker_buffer = 0
                end
                return true
            end
        }))
        G.E_MANAGER:add_event(Event({
            func = function()
                G.GAME.starting_params.ante_scaling = G.GAME.starting_params.ante_scaling * 3
                return true
            end
        }))
    end
}