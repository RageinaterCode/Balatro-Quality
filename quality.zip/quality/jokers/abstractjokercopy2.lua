
SMODS.Joker{ --Abstract Joker
    key = "abstractjokercopy2",
    config = {
        extra = {
            jokercount = 0
        }
    },
    loc_txt = {
        ['name'] = 'Abstract Joker',
        ['text'] = {
            [1] = '{X:red,C:white}x1.5{} Mult for each {C:attention}Joker{} card',
            [2] = '{C:inactive}(Currently{} {X:red,C:white}x#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = "quality_perfected",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {(#(G.jokers and (G.jokers and G.jokers.cards or {}) or {})) * 1.5}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = (#(G.jokers and G.jokers.cards or {})) * 1.5
            }
        end
    end
}