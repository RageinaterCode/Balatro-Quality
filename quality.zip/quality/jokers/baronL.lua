
SMODS.Joker{ --Baron
    key = "baronL",
    config = {
        extra = {
            xmult0 = 2,
            xmult = 2
        }
    },
    loc_txt = {
        ['name'] = 'Baron',
        ['text'] = {
            [1] = 'Each {C:attention}Steel{} {C:attention}King{} held in hand gives {X:red,C:white}X2{} Mult',
            [2] = 'All scored {C:attention}Kings{} are given {C:attention}Red{} Seal {C:attention}Steel{}',
            [3] = '',
            [4] = '{C:attention}Steel{} {C:attention}Kings{} score {C:attention}twice{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 5,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = "quality_mythic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if (context.other_card:get_id() == 13) and (SMODS.get_enhancements(context.other_card)["m_steel"] == true) then
                return {
                    Xmult = 2,
                    extra = {
                        Xmult = 2
                    }
                }
            end
        end
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 13 then
                local scored_card = context.other_card
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        scored_card:set_ability(G.P_CENTERS.m_steel)
                        scored_card:set_seal("Red", true)
                        card_eval_status_text(scored_card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.ORANGE})
                        return true
                    end
                }))
            end
        end
    end
}