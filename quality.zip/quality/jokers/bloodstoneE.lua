
SMODS.Joker{ --Bloodstone
    key = "bloodstoneE",
    config = {
        extra = {
            odds = 2,
            xmult0 = 1.5,
            xmult = 2,
            odds2 = 2,
            xmult2 = 2,
            odds3 = 2,
            xmult3 = 1.5
        }
    },
    loc_txt = {
        ['name'] = 'Bloodstone',
        ['text'] = {
            [1] = '{C:green}#1# in #2#{} chance for played cards with {C:hearts}Heart{} suit',
            [2] = 'to give {X:red,C:white}X2{} Mult when scored',
            [3] = '',
            [4] = '{C:uncommon}#1# in #2# chance{} for scored {C:green}Lucky Cards{} to also give {X:mult,C:white}x1.5{} Mult'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 9
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 15,
    rarity = "quality_perfected",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_quality_bloodstoneE')
        local new_numerator2, new_denominator2 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds2, 'j_quality_bloodstoneE')
        local new_numerator3, new_denominator3 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds3, 'j_quality_bloodstoneE')
        local new_numerator4, new_denominator4 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds4, 'j_quality_bloodstoneE')
        return {vars = {new_numerator, new_denominator, new_numerator2, new_denominator2, new_numerator3, new_denominator3, new_numerator4, new_denominator4}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (SMODS.get_enhancements(context.other_card)["m_lucky"] == true and context.other_card:is_suit("Hearts")) then
                if SMODS.pseudorandom_probability(card, 'group_0_bb1ceac8', 1, card.ability.extra.odds, 'j_quality_bloodstoneE', false) then
                    SMODS.calculate_effect({Xmult = 1.5}, card)
                end
                if SMODS.pseudorandom_probability(card, 'group_1_91c481b1', 1, card.ability.extra.odds, 'j_quality_bloodstoneE', false) then
                    SMODS.calculate_effect({Xmult = 2}, card)
                end
            elseif context.other_card:is_suit("Hearts") then
                if SMODS.pseudorandom_probability(card, 'group_0_76750bc1', 1, card.ability.extra.odds, 'j_quality_bloodstoneE', false) then
                    SMODS.calculate_effect({Xmult = 2}, card)
                end
            elseif SMODS.get_enhancements(context.other_card)["m_lucky"] == true then
                if SMODS.pseudorandom_probability(card, 'group_0_cbe12932', 1, card.ability.extra.odds, 'j_quality_bloodstoneE', false) then
                    SMODS.calculate_effect({Xmult = 1.5}, card)
                end
            end
        end
    end
}