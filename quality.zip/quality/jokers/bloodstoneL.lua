
SMODS.Joker{ --Bloodstone
    key = "bloodstoneL",
    config = {
        extra = {
            xmult0 = 2,
            xmult = 2.5,
            xmult2 = 2.5,
            xmult3 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Bloodstone',
        ['text'] = {
            [1] = 'Played cards with {C:hearts}Heart{} suit',
            [2] = 'give {X:red,C:white}X2.5{} Mult when scored',
            [3] = '',
            [4] = 'Scored {C:green}Lucky Cards{} also give {X:mult,C:white}x2{} Mult'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 1,
        y = 9
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = "quality_mythic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (SMODS.get_enhancements(context.other_card)["m_lucky"] == true and context.other_card:is_suit("Hearts")) then
                return {
                    Xmult = 2,
                    extra = {
                        Xmult = 2.5
                    }
                }
            elseif context.other_card:is_suit("Hearts") then
                return {
                    Xmult = 2.5
                }
            elseif SMODS.get_enhancements(context.other_card)["m_lucky"] == true then
                return {
                    Xmult = 2
                }
            end
        end
    end
}