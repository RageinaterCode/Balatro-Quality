
SMODS.Joker{ --Bloodstone
    key = "bloodstoneU",
    config = {
        extra = {
            odds = 2,
            xmult0 = 1.75
        }
    },
    loc_txt = {
        ['name'] = 'Bloodstone',
        ['text'] = {
            [1] = '{C:green}#1# in #2#{} chance for played cards with {C:hearts}Heart{} suit',
            [2] = 'to give {X:red,C:white}X1.75{} Mult when scored'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 9
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = "quality_improved",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_quality_bloodstoneU') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Hearts") then
                if SMODS.pseudorandom_probability(card, 'group_0_76750bc1', 1, card.ability.extra.odds, 'j_quality_bloodstoneU', false) then
                    SMODS.calculate_effect({Xmult = 1.75}, card)
                end
            end
        end
    end
}