
SMODS.Joker{ --Credit Card
    key = "creditcardR",
    config = {
        extra = {
            debt_amount = '50'
        }
    },
    loc_txt = {
        ['name'] = 'Credit Card',
        ['text'] = {
            [1] = 'Go up to {C:red}-$50{} in debt'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 1,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = "quality_refined",
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
    end,
    
    add_to_deck = function(self, card, from_debuff)
        G.GAME.bankrupt_at = G.GAME.bankrupt_at - 50
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        G.GAME.bankrupt_at = G.GAME.bankrupt_at + 50
    end
}