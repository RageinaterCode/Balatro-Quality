
SMODS.Joker{ --Gluttonous Joker
    key = "gluttonousjokerL",
    config = {
        extra = {
            xmult0 = 3,
            xchips0 = 3,
            odds = 4
        }
    },
    loc_txt = {
        ['name'] = 'Gluttonous Joker',
        ['text'] = {
            [1] = 'Played cards with {C:clubs}Club{} suit give {X:red,C:white}x3{} Mult and {X:blue,C:white}x3{} Chips when scored',
            [2] = '{C:green}#1# in #2#{} chance to give a {C:tarot}Moon{} card when triggered'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 11,
    rarity = "quality_mythic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_quality_gluttonousjokerL') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Clubs") then
                return {
                    Xmult = 3,
                    extra = {
                        x_chips = 3,
                        colour = G.C.DARK_EDITION
                    }
                    ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_af297201', 1, card.ability.extra.odds, 'j_quality_gluttonousjokerL', false) then
                            for i = 1, math.min(1, G.consumeables.config.card_limit - #G.consumeables.cards) do
                                G.E_MANAGER:add_event(Event({
                                    trigger = 'after',
                                    delay = 0.4,
                                    func = function()
                                        play_sound('timpani')
                                        SMODS.add_card({ set = 'Tarot', key = 'c_moon'})                            
                                        card:juice_up(0.3, 0.5)
                                        return true
                                    end
                                }))
                            end
                            delay(0.6)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = created_consumable and localize('k_plus_tarot') or nil, colour = G.C.PURPLE})
                        end
                        return true
                    end
                }
            end
        end
    end
}