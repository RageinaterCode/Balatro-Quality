
SMODS.Joker{ --Gluttonous Joker
    key = "gluttonousjokerU",
    config = {
        extra = {
            mult0 = 5
        }
    },
    loc_txt = {
        ['name'] = 'Gluttonous Joker',
        ['text'] = {
            [1] = 'Played cards with {C:clubs}Club{} suit give {C:mult}+5{} Mult when scored'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = "quality_improved",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Clubs") then
                return {
                    mult = 5
                }
            end
        end
    end
}