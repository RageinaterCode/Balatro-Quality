
SMODS.Joker{ --Greedy Joker
    key = "greedyjokerR",
    config = {
        extra = {
            mult0 = 8
        }
    },
    loc_txt = {
        ['name'] = 'Greedy Joker',
        ['text'] = {
            [1] = 'Played cards with {C:diamonds}Diamond{} suit give {C:mult}+8{} Mult when scored'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 5,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = "quality_refined",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Diamonds") then
                return {
                    mult = 8
                }
            end
        end
    end
}