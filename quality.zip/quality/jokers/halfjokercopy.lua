
SMODS.Joker{ --Half Joker
    key = "halfjokercopy",
    config = {
        extra = {
            mult0 = 25,
            chips0 = 25
        }
    },
    loc_txt = {
        ['name'] = 'Half Joker',
        ['text'] = {
            [1] = '{C:mult}+25{} Mult and {C:blue}+25{} Chips if {C:attention}scored{} hand contains {C:attention}4{} or fewer cards'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 5,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = "quality_refined",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big(#context.scoring_hand) <= to_big(4) then
                return {
                    mult = 25,
                    extra = {
                        chips = 25,
                        colour = G.C.CHIPS
                    }
                }
            end
        end
    end
}