
SMODS.Joker{ --Half Joker
    key = "halfjokercopy2",
    config = {
        extra = {
            mult0 = 20,
            chips0 = 20
        }
    },
    loc_txt = {
        ['name'] = 'Half Joker',
        ['text'] = {
            [1] = '{C:mult}+20{} Mult and {C:blue}+20{} Chips if {C:attention}scored{} hand contains {C:attention}3{} or fewer cards'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = "quality_improved",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big(#context.scoring_hand) <= to_big(3) then
                return {
                    mult = 20,
                    extra = {
                        chips = 20,
                        colour = G.C.CHIPS
                    }
                }
            end
        end
    end
}