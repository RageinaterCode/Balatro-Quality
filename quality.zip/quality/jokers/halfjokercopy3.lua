
SMODS.Joker{ --Half Joker
    key = "halfjokercopy3",
    config = {
        extra = {
            mult0 = 30,
            chips0 = 50,
            xmult0 = 3
        }
    },
    loc_txt = {
        ['name'] = 'Half Joker',
        ['text'] = {
            [1] = '{C:mult}+30{} Mult and {C:blue}+50{} Chips if {C:attention}scored{} hand contains {C:attention}4{} or fewer cards',
            [2] = '{X:red,C:white}x3{} Mult if played hand contains {C:attention}3{} or fewer cards'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = "quality_perfected",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big(#context.scoring_hand) <= to_big(4) then
                return {
                    mult = 30,
                    extra = {
                        chips = 50,
                        colour = G.C.CHIPS
                    }
                }
            elseif to_big(#context.scoring_hand) <= to_big(3) then
                return {
                    Xmult = 3
                }
            end
        end
    end
}