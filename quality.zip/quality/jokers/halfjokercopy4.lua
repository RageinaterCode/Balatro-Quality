
SMODS.Joker{ --Half Joker
    key = "halfjokercopy4",
    config = {
        extra = {
            xchips0 = 3,
            xmult0 = 3
        }
    },
    loc_txt = {
        ['name'] = 'Half Joker',
        ['text'] = {
            [1] = '{X:mult,C:white}x3{} Mult and {X:chips,C:white}x3{} Chips if {C:attention}scored{} hand contains {C:attention}3{} or fewer cards'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 7,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 13,
    rarity = "quality_mythic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big(#context.scoring_hand) <= to_big(3) then
                return {
                    x_chips = 3,
                    extra = {
                        Xmult = 3
                    }
                }
            end
        end
    end
}