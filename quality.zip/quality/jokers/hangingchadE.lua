
SMODS.Joker{ --Hanging Chad
    key = "hangingchadE",
    config = {
        extra = {
            repetitions0 = 3,
            repetitions = 3
        }
    },
    loc_txt = {
        ['name'] = 'Hanging Chad',
        ['text'] = {
            [1] = 'Retrigger {C:attention}first{} and {C:attention}last{} played card used in scoring {C:attention}3{} additional times'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 9
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 14,
    rarity = "quality_perfected",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if context.other_card == context.scoring_hand[1] then
                return {
                    repetitions = 3,
                    message = localize('k_again_ex')
                }
            elseif context.other_card == context.scoring_hand[#context.scoring_hand] then
                return {
                    repetitions = 3,
                    message = localize('k_again_ex')
                }
            end
        end
    end
}