
SMODS.Joker{ --Hanging Chad
    key = "hangingchadU",
    config = {
        extra = {
            repetitions0 = 3
        }
    },
    loc_txt = {
        ['name'] = 'Hanging Chad',
        ['text'] = {
            [1] = 'Retrigger {C:attention}first{} played card used in scoring {C:attention}3{} additional times'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = "quality_improved",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if context.other_card == context.scoring_hand[1] then
                return {
                    repetitions = 3,
                    message = localize('k_again_ex')
                }
            end
        end
    end
}