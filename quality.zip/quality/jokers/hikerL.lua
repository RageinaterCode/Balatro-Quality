
SMODS.Joker{ --Hiker
    key = "hikerL",
    config = {
        extra = {
            pb_bonus_546bed6e = 50,
            pb_mult_bad1b891 = 5,
            odds = 2,
            pb_x_chips_7e0c50ee = 1.01,
            pb_x_mult_83ed7fde = 1.01
        }
    },
    loc_txt = {
        ['name'] = 'Hiker',
        ['text'] = {
            [1] = 'Every played {C:attention}card{} permanently',
            [2] = 'gains {C:blue}+50{} Chips and {C:red}+5{} Mult when scored',
            [3] = '{C:green}#1# in #2#{} chance for played {C:attention}cards{} to also',
            [4] = 'gain {X:mult,C:white}x1.01{} Mult and {X:chips,C:white}x1.01{} Chips permanently'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 18,
    rarity = "quality_mythic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_quality_hikerL') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if true then
                context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus or 0
                context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus + 50
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult or 0
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult + 5
                return {
                    extra = { message = localize('k_upgrade_ex'), colour = G.C.CHIPS }, card = card
                    ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_40085afb', 1, card.ability.extra.odds, 'j_quality_hikerL', false) then
                            context.other_card.ability.perma_x_chips = context.other_card.ability.perma_x_chips or 0
                            context.other_card.ability.perma_x_chips = context.other_card.ability.perma_x_chips + 1.01
                            context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult or 0
                            context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult + 1.01
                            
                        end
                        return true
                    end
                }
            end
        end
    end
}