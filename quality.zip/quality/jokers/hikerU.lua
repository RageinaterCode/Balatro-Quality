
SMODS.Joker{ --Hiker
    key = "hikerU",
    config = {
        extra = {
            pb_bonus_546bed6e = 15
        }
    },
    loc_txt = {
        ['name'] = 'Hiker',
        ['text'] = {
            [1] = 'Every played {C:attention}card{} permanently',
            [2] = 'gains {C:blue}+15{} Chips when scored'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = "quality_improved",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus or 0
            context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus + 15
            return {
                extra = { message = localize('k_upgrade_ex'), colour = G.C.CHIPS }, card = card
            }
        end
    end
}