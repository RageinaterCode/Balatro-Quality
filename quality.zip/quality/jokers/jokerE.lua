
SMODS.Joker{ --Joker
    key = "jokerE",
    config = {
        extra = {
            hand_size_increase = '4',
            mult0 = 4,
            chips0 = 4,
            dollars0 = 4,
            hand_size0 = 4
        }
    },
    loc_txt = {
        ['name'] = 'Joker',
        ['text'] = {
            [1] = '{C:mult}+4{} Mult {C:chips}+4{} Chips',
            [2] = '',
            [3] = '{C:money}+$4{} on payout',
            [4] = '{X:enhanced,C:white}+4 {} Handsize'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = "quality_perfected",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                mult = 4,
                extra = {
                    chips = 4,
                    colour = G.C.CHIPS
                }
            }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars + 4
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(4), colour = G.C.MONEY})
                    return true
                end
            }
        end
        if context.selling_self  then
            return {
                
                func = function()
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(4).." Hand Limit", colour = G.C.BLUE})
                    
                    G.hand:change_size(-4)
                    return true
                end
            }
        end
    end,
    
    add_to_deck = function(self, card, from_debuff)
        G.hand:change_size(4)
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        G.hand:change_size(-4)
    end
}