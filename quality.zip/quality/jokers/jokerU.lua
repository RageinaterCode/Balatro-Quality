
SMODS.Joker{ --Joker
    key = "jokerU",
    config = {
        extra = {
            mult0 = 4,
            chips0 = 4
        }
    },
    loc_txt = {
        ['name'] = 'Joker',
        ['text'] = {
            [1] = '{C:mult}+4{} Mult {C:chips}+4{} Chips'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 3,
    rarity = "quality_improved",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                mult = 4,
                extra = {
                    chips = 4,
                    colour = G.C.CHIPS
                }
            }
        end
    end
}