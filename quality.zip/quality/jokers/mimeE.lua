
SMODS.Joker{ --Mime
    key = "mimeE",
    config = {
        extra = {
            repetitions0 = 2,
            repetitions = 3,
            repetitions2 = 3
        }
    },
    loc_txt = {
        ['name'] = 'Mime',
        ['text'] = {
            [1] = 'Retrigger all card {C:attention}held in hand{} abilities {C:attention}2{} times',
            [2] = 'Scored {C:attention}Gold{} cards retrigger {C:attention}3{} times'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 15,
    rarity = "quality_perfected",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.hand and context.end_of_round and (next(context.card_effects[1]) or #context.card_effects > 1)  then
            if SMODS.get_enhancements(context.other_card)["m_steel"] == true then
                return {
                    repetitions = 2,
                    message = localize('k_again_ex')
                }
            end
        end
        if context.repetition and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_gold"] == true then
                return {
                    repetitions = 3,
                    message = localize('k_again_ex')
                }
            end
        end
        if context.repetition and context.cardarea == G.hand and context.end_of_round and (next(context.card_effects[1]) or #context.card_effects > 1)  then
            if (context.other_card.seal == "Blue" or SMODS.get_enhancements(context.other_card)["m_gold"] == true) then
                return {
                    repetitions = 3,
                    message = localize('k_again_ex')
                }
            end
        end
    end
}