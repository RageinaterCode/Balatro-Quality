
SMODS.Joker{ --Mime
    key = "mimeU",
    config = {
        extra = {
            repetitions0 = 1,
            repetitions = 1,
            repetitions2 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Mime',
        ['text'] = {
            [1] = 'Retrigger all card {C:attention}held in hand{} abilities',
            [2] = 'Scored {C:attention}Gold{} cards retrigger {C:attention}1{} time'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 9,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = "quality_improved",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.hand and context.end_of_round and (next(context.card_effects[1]) or #context.card_effects > 1)  then
            return {
                repetitions = 1,
                message = localize('k_again_ex')
            }
        end
        if context.repetition and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_gold"] == true then
                return {
                    repetitions = 1,
                    message = localize('k_again_ex')
                }
            end
        end
        if context.repetition and context.cardarea == G.hand and context.end_of_round and (next(context.card_effects[1]) or #context.card_effects > 1)  then
            if (context.other_card.seal == "Blue" or SMODS.get_enhancements(context.other_card)["m_gold"] == true) then
                return {
                    repetitions = 1,
                    message = localize('k_again_ex')
                }
            end
        end
    end
}