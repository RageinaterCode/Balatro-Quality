
SMODS.Joker{ --Oops! All 6s
    key = "oopsall6U",
    config = {
        extra = {
            mod_probability0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Oops! All 6s',
        ['text'] = {
            [1] = 'Doubles all {C:attention}listed{} {C:green}probabilities{}',
            [2] = '(ex: {C:green}1 in 3{} -> {C:green}2 in 3{})',
            [3] = 'Create {C:tarot}The Magician{} when failing any {C:green}probability{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 1,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = "quality_improved",
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.mod_probability  then
            local numerator, denominator = context.numerator, context.denominator
            numerator = numerator * (2)
            return {
                numerator = numerator, 
                denominator = denominator
            }
        end
        if context.pseudorandom_result  then
            if not context.result then
                return {
                    func = function()
                        
                        for i = 1, math.min(1, G.consumeables.config.card_limit - #G.consumeables.cards) do
                            G.E_MANAGER:add_event(Event({
                                trigger = 'after',
                                delay = 0.4,
                                func = function()
                                    play_sound('timpani')
                                    SMODS.add_card({ set = 'Tarot', key = 'c_magician'})                            
                                    card:juice_up(0.3, 0.5)
                                    return true
                                end
                            }))
                        end
                        delay(0.6)
                        
                        if created_consumable then
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_tarot'), colour = G.C.PURPLE})
                        end
                        return true
                    end
                }
            end
        end
    end
}