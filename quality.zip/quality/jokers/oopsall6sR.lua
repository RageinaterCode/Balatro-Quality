
SMODS.Joker{ --Oops! All 6s
    key = "oopsall6sR",
    config = {
        extra = {
            mod_probability0 = 3
        }
    },
    loc_txt = {
        ['name'] = 'Oops! All 6s',
        ['text'] = {
            [1] = 'Triples all {C:attention}listed{} {C:green}probabilities{}',
            [2] = '(ex: {C:green}1 in 3{} -> {C:green}3 in 3{})'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = "quality_refined",
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.mod_probability and not context.blueprint then
            local numerator, denominator = context.numerator, context.denominator
            numerator = numerator * (3)
            return {
                numerator = numerator, 
                denominator = denominator
            }
        end
    end
}