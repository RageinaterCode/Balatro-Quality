
SMODS.Joker{ --Photograph
    key = "photographL",
    config = {
        extra = {
            xmult0 = 2.5,
            xchips0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Photograph',
        ['text'] = {
            [1] = 'All {C:attention}face{} cards give {X:red,C:white}X3{} Mult and {X:chips,C:white}x2{} Chips when scored'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 1,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = "quality_mythic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_face() then
                return {
                    Xmult = 2.5,
                    extra = {
                        x_chips = 2,
                        colour = G.C.DARK_EDITION
                    }
                }
            end
        end
    end
}