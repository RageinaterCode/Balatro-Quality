
SMODS.Joker{ --Smiley Face
    key = "smileyfaceE",
    config = {
        extra = {
            mult0 = 10,
            chips0 = 10
        }
    },
    loc_txt = {
        ['name'] = 'Smiley Face',
        ['text'] = {
            [1] = 'Played {C:attention}face{} cards give {C:mult}+10{} Mult and {C:blue}+10{} Chips when scored'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = "quality_perfected",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_face() then
                return {
                    mult = 10,
                    extra = {
                        chips = 10,
                        colour = G.C.CHIPS
                    }
                }
            end
        end
    end
}