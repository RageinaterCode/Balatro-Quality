
SMODS.Joker{ --Smiley Face
    key = "smileyfaceL",
    config = {
        extra = {
            Mult = 10,
            Chips = 10,
            odds = 2
        }
    },
    loc_txt = {
        ['name'] = 'Smiley Face',
        ['text'] = {
            [1] = 'Played {C:attention}face{} cards give {C:red}Mult{} and {C:blue}Chips{} when scored',
            [2] = '{C:green}#1# in #2#{} chance to gain {C:red}+5{} Mult and {C:blue}+5{} Chips permanently',
            [3] = '',
            [4] = '{C:inactive}(Currently{} {C:red}+#1#{} {C:inactive}Mult){} and {C:inactive}(Currently{} {C:blue}+#2#{} {C:inactive}Chips){}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = "quality_mythic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_quality_smileyfaceL') 
        return {vars = {card.ability.extra.Mult, card.ability.extra.Chips, new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_face() then
                return {
                    chips = card.ability.extra.Chips,
                    extra = {
                        mult = card.ability.extra.Mult
                    }
                    ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_1d7faeec', 1, card.ability.extra.odds, 'j_quality_smileyfaceL', false) then
                            card.ability.extra.Chips = (card.ability.extra.Chips) + 5
                            card.ability.extra.Mult = (card.ability.extra.Mult) + 5
                            
                        end
                        return true
                    end
                }
            end
        end
    end
}