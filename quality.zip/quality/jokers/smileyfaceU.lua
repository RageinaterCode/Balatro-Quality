
SMODS.Joker{ --Smiley Face
    key = "smileyfaceU",
    config = {
        extra = {
            mult0 = 7
        }
    },
    loc_txt = {
        ['name'] = 'Smiley Face',
        ['text'] = {
            [1] = 'Played {C:attention}face{} cards give {C:mult}+7{} Mult when scored'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "quality_improved",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_face() then
                return {
                    mult = 7
                }
            end
        end
    end
}