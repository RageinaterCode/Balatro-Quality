
SMODS.Joker{ --Sock And Buskin
    key = "sockandbuskinL",
    config = {
        extra = {
            repetitions0 = 2,
            odds = 2,
            xchips0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Sock And Buskin',
        ['text'] = {
            [1] = 'Retrigger all played {C:attention}face{} cards {C:attention}2{} times',
            [2] = 'Scored {C:attention}face{} cards have a {C:green}#1# in #2#{} chance to give {X:chips,C:white}x2{} Chips'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 18,
    rarity = "quality_mythic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_quality_sockandbuskinL') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if context.other_card:is_face() then
                return {
                    repetitions = 2,
                    message = localize('k_again_ex')
                    ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_4ae30e41', 1, card.ability.extra.odds, 'j_quality_sockandbuskinL', false) then
                            SMODS.calculate_effect({x_chips = 2}, card)
                        end
                        return true
                    end
                }
            end
        end
    end
}