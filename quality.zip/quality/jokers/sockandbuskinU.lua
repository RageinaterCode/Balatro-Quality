
SMODS.Joker{ --Sock and Buskin
    key = "sockandbuskinU",
    config = {
        extra = {
            repetitions0 = 1,
            odds = 4,
            repetitions = 1
        }
    },
    loc_txt = {
        ['name'] = 'Sock and Buskin',
        ['text'] = {
            [1] = 'Retrigger all played {C:attention}face{} cards',
            [2] = 'Scored {C:attention}face{} cards have a {C:green}#1# in #2#{} chance to trigger {C:attention}1{} more time'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 7,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = "quality_improved",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_quality_sockandbuskinU') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if context.other_card:is_face() then
                return {
                    repetitions = 1,
                    message = localize('k_again_ex')
                    ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_77fb715f', 1, card.ability.extra.odds, 'j_quality_sockandbuskinU', false) then
                            
                            return {repetitions = 1}
                        end
                        return true
                    end
                }
            end
        end
    end
}