
SMODS.Joker{ --Space Joker
    key = "spacejoker",
    config = {
        extra = {
            levels0 = 1,
            levels = 1,
            levels2 = 1,
            levels3 = 1,
            levels4 = 1,
            levels5 = 1,
            levels6 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Space Joker',
        ['text'] = {
            [1] = 'Upgrade level of played {C:attention}poker hand{} {C:attention}{}',
            [2] = 'Upgrade level of {C:attention}6{} random {C:attention}poker hands{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 9
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 11,
    rarity = "quality_perfected",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.before and context.cardarea == G.jokers  then
            local target_hand = (context.scoring_name or "High Card")
            level_up_hand(card, target_hand, true, 1)
            local available_hands = {}
            for hand, value in pairs(G.GAME.hands) do
                if value.visible and value.level >= to_big(1) then
                    table.insert(available_hands, hand)
                end
            end
            local target_hand2 = #available_hands > 0 and pseudorandom_element(available_hands, pseudoseed('level_up_hand')) or "High Card"
            level_up_hand(card, target_hand2, true, 1)
            local available_hands = {}
            for hand, value in pairs(G.GAME.hands) do
                if value.visible and value.level >= to_big(1) then
                    table.insert(available_hands, hand)
                end
            end
            local target_hand3 = #available_hands > 0 and pseudorandom_element(available_hands, pseudoseed('level_up_hand')) or "High Card"
            level_up_hand(card, target_hand3, true, 1)
            local available_hands = {}
            for hand, value in pairs(G.GAME.hands) do
                if value.visible and value.level >= to_big(1) then
                    table.insert(available_hands, hand)
                end
            end
            local target_hand4 = #available_hands > 0 and pseudorandom_element(available_hands, pseudoseed('level_up_hand')) or "High Card"
            level_up_hand(card, target_hand4, true, 1)
            local available_hands = {}
            for hand, value in pairs(G.GAME.hands) do
                if value.visible and value.level >= to_big(1) then
                    table.insert(available_hands, hand)
                end
            end
            local target_hand5 = #available_hands > 0 and pseudorandom_element(available_hands, pseudoseed('level_up_hand')) or "High Card"
            level_up_hand(card, target_hand5, true, 1)
            local available_hands = {}
            for hand, value in pairs(G.GAME.hands) do
                if value.visible and value.level >= to_big(1) then
                    table.insert(available_hands, hand)
                end
            end
            local target_hand6 = #available_hands > 0 and pseudorandom_element(available_hands, pseudoseed('level_up_hand')) or "High Card"
            level_up_hand(card, target_hand6, true, 1)
            local available_hands = {}
            for hand, value in pairs(G.GAME.hands) do
                if value.visible and value.level >= to_big(1) then
                    table.insert(available_hands, hand)
                end
            end
            local target_hand7 = #available_hands > 0 and pseudorandom_element(available_hands, pseudoseed('level_up_hand')) or "High Card"
            level_up_hand(card, target_hand7, true, 1)
            return {
                message = localize('k_level_up_ex'),
                extra = {
                    message = localize('k_level_up_ex'),
                    colour = G.C.RED,
                    extra = {
                        message = localize('k_level_up_ex'),
                        colour = G.C.RED,
                        extra = {
                            message = localize('k_level_up_ex'),
                            colour = G.C.RED,
                            extra = {
                                message = localize('k_level_up_ex'),
                                colour = G.C.RED,
                                extra = {
                                    message = localize('k_level_up_ex'),
                                    colour = G.C.RED,
                                    extra = {
                                        message = localize('k_level_up_ex'),
                                        colour = G.C.RED
                                    }
                                }
                            }
                        }
                    }
                }
            }
        end
    end
}