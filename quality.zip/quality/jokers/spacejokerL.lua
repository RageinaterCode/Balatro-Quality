
SMODS.Joker{ --Space Joker
    key = "spacejokerL",
    config = {
        extra = {
            levels0 = 1,
            levels = 1,
            levels2 = 1,
            levels3 = 1,
            levels4 = 1,
            levels5 = 1,
            levels6 = 1,
            levels7 = 1,
            levels8 = 1,
            levels9 = 1,
            levels10 = 1,
            levels11 = 1,
            levels12 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Space Joker',
        ['text'] = {
            [1] = 'Upgrade level of played {C:attention}poker hand{} {C:attention}2{} times',
            [2] = 'Upgrade all other {C:attention}poker hands{} {C:attention}once{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 7,
        y = 9
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 13,
    rarity = "quality_mythic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.before and context.cardarea == G.jokers  then
            local target_hand = (context.scoring_name or "High Card")
            level_up_hand(card, target_hand, true, 1)
            local target_hand2 = "High Card"
            level_up_hand(card, target_hand2, true, 1)
            local target_hand3 = "Pair"
            level_up_hand(card, target_hand3, true, 1)
            local target_hand4 = "Two Pair"
            level_up_hand(card, target_hand4, true, 1)
            local target_hand5 = "Three of a Kind"
            level_up_hand(card, target_hand5, true, 1)
            local target_hand6 = "Straight"
            level_up_hand(card, target_hand6, true, 1)
            local target_hand7 = "Flush"
            level_up_hand(card, target_hand7, true, 1)
            local target_hand8 = "Full House"
            level_up_hand(card, target_hand8, true, 1)
            local target_hand9 = "Four of a Kind"
            level_up_hand(card, target_hand9, true, 1)
            local target_hand10 = "Five of a Kind"
            level_up_hand(card, target_hand10, true, 1)
            local target_hand11 = "Straight Flush"
            level_up_hand(card, target_hand11, true, 1)
            local target_hand12 = "Flush House"
            level_up_hand(card, target_hand12, true, 1)
            local target_hand13 = "Flush Five"
            level_up_hand(card, target_hand13, true, 1)
            return {
                message = localize('k_level_up_ex'),
                extra = {
                    message = localize('k_level_up_ex'),
                    colour = G.C.RED,
                    extra = {
                        message = localize('k_level_up_ex'),
                        colour = G.C.RED,
                        extra = {
                            message = localize('k_level_up_ex'),
                            colour = G.C.RED,
                            extra = {
                                message = localize('k_level_up_ex'),
                                colour = G.C.RED,
                                extra = {
                                    message = localize('k_level_up_ex'),
                                    colour = G.C.RED,
                                    extra = {
                                        message = localize('k_level_up_ex'),
                                        colour = G.C.RED,
                                        extra = {
                                            message = localize('k_level_up_ex'),
                                            colour = G.C.RED,
                                            extra = {
                                                message = localize('k_level_up_ex'),
                                                colour = G.C.RED,
                                                extra = {
                                                    message = localize('k_level_up_ex'),
                                                    colour = G.C.RED,
                                                    extra = {
                                                        message = localize('k_level_up_ex'),
                                                        colour = G.C.RED,
                                                        extra = {
                                                            message = localize('k_level_up_ex'),
                                                            colour = G.C.RED,
                                                            extra = {
                                                                message = localize('k_level_up_ex'),
                                                                colour = G.C.RED
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        end
    end
}