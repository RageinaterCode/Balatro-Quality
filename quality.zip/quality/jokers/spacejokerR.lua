
SMODS.Joker{ --Space Joker
    key = "spacejokerR",
    config = {
        extra = {
            levels0 = 1,
            odds = 2,
            levels = 1
        }
    },
    loc_txt = {
        ['name'] = 'Space Joker',
        ['text'] = {
            [1] = 'Upgrade level of played {C:attention}poker hand{}',
            [2] = '{C:green}#1# in #2#{} chance to upgrade {C:attention}twice{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 5,
        y = 9
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = "quality_refined",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_quality_spacejokerR') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.before and context.cardarea == G.jokers  then
            if true then
                local target_hand = (context.scoring_name or "High Card")
                level_up_hand(card, target_hand, true, 1)
                return {
                    message = localize('k_level_up_ex')
                    ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_8fa2df7d', 1, card.ability.extra.odds, 'j_quality_spacejokerR', false) then
                            local target_hand2 = (context.scoring_name or "High Card")
                            level_up_hand(card, target_hand2, true, 1)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_level_up_ex'), colour = G.C.RED})
                        end
                        return true
                    end
                }
            end
        end
    end
}