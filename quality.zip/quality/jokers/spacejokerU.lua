
SMODS.Joker{ --Space Joker
    key = "spacejokerU",
    config = {
        extra = {
            odds = 2,
            levels0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Space Joker',
        ['text'] = {
            [1] = '{C:green}#1# in #2#{} chance to upgrade level of played {C:attention}poker hand{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 4,
        y = 9
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = "quality_improved",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_quality_spacejokerU') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.before and context.cardarea == G.jokers  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_eda176d7', 1, card.ability.extra.odds, 'j_quality_spacejokerU', false) then
                    local target_hand = (context.scoring_name or "High Card")
                    level_up_hand(card, target_hand, true, 1)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_level_up_ex'), colour = G.C.RED})
                end
            end
        end
    end
}