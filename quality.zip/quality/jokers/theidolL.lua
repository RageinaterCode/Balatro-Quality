
SMODS.Joker{ --The Idol
    key = "theidolL",
    config = {
        extra = {
            odds = 2,
            repetitions0 = 1,
            xmult0 = 2,
            xchips0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'The Idol',
        ['text'] = {
            [1] = 'Each played {C:attention}#2#{} of {C:attention}#1#{} gives {X:red,C:white}X2.5{} Mult and {X:chips,C:white}x2.5{} Chips when scored',
            [2] = 'Card changes every round',
            [3] = '',
            [4] = '{C:green}#1# in #2#{} chance to trigger {C:red}twice{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 9
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 15,
    rarity = "quality_mythic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_quality_theidolL') 
        return {vars = {localize((G.GAME.current_round.suitvar_card or {}).suit or 'Spades', 'suits_singular'), localize((G.GAME.current_round.rankvar_card or {}).rank or 'Ace', 'ranks'), new_numerator, new_denominator}}
    end,
    
    set_ability = function(self, card, initial)
        G.GAME.current_round.suitvar_card = { suit = 'Spades' }
        G.GAME.current_round.rankvar_card = { rank = 'Ace', id = 14 }
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 14 and context.other_card:is_suit(G.GAME.current_round.suitvar_card.suit)) then
                if SMODS.pseudorandom_probability(card, 'group_0_47c5a4bc', 1, card.ability.extra.odds, 'j_quality_theidolL', false) then
                    
                    return {repetitions = 1}
                end
            elseif (context.other_card:get_id() == 14 and context.other_card:is_suit(G.GAME.current_round.suitvar_card.suit)) then
                return {
                    Xmult = 2,
                    extra = {
                        x_chips = 2,
                        colour = G.C.DARK_EDITION
                    }
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  and not context.blueprint then
            if G.playing_cards then
                local valid_suitvar_cards = {}
                for _, v in ipairs(G.playing_cards) do
                    if not SMODS.has_no_suit(v) then
                        valid_suitvar_cards[#valid_suitvar_cards + 1] = v
                    end
                end
                if valid_suitvar_cards[1] then
                    local suitvar_card = pseudorandom_element(valid_suitvar_cards, pseudoseed('suitvar' .. G.GAME.round_resets.ante))
                    G.GAME.current_round.suitvar_card.suit = suitvar_card.base.suit
                end
            end
            if G.playing_cards then
                local valid_rankvar_cards = {}
                for _, v in ipairs(G.playing_cards) do
                    if not SMODS.has_no_rank(v) then
                        valid_rankvar_cards[#valid_rankvar_cards + 1] = v
                    end
                end
                if valid_rankvar_cards[1] then
                    local rankvar_card = pseudorandom_element(valid_rankvar_cards, pseudoseed('rankvar' .. G.GAME.round_resets.ante))
                    G.GAME.current_round.rankvar_card.rank = rankvar_card.base.value
                    G.GAME.current_round.rankvar_card.id = rankvar_card.base.id
                end
            end
        end
    end
}