
SMODS.Joker{ --Turtle Bean
    key = "turtlebean",
    config = {
        extra = {
            handsizevarL = 8
        }
    },
    loc_txt = {
        ['name'] = 'Turtle Bean',
        ['text'] = {
            [1] = '{C:attention}+8{} hand size'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 4,
        y = 10
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 17,
    rarity = "quality_mythic",
    blueprint_compat = false,
    eternal_compat = false,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.handsizevarL}}
    end,
    
    calculate = function(self, card, context)
    end,
    
    add_to_deck = function(self, card, from_debuff)
        G.hand:change_size(card.ability.extra.handsizevarL)
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        G.hand:change_size(-card.ability.extra.handsizevarL)
    end
}