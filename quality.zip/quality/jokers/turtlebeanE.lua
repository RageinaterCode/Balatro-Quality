
SMODS.Joker{ --Turtle Bean
    key = "turtlebeanE",
    config = {
        extra = {
            handsizevarE = 8
        }
    },
    loc_txt = {
        ['name'] = 'Turtle Bean',
        ['text'] = {
            [1] = '{C:attention}+8{} hand size, reduces by {C:attention}1{} each round'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 4,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 13,
    rarity = "quality_perfected",
    blueprint_compat = false,
    eternal_compat = false,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.handsizevarE}}
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  and not context.blueprint then
            if to_big((card.ability.extra.handsizevarE or 0)) < to_big(1) then
                return {
                    func = function()
                        local target_joker = card
                        
                        if target_joker then
                            target_joker.getting_sliced = true
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                        end
                        return true
                    end
                }
            else
                return {
                    func = function()
                        card.ability.extra.handsizevarE = math.max(0, (card.ability.extra.handsizevarE) - 1)
                        return true
                    end,
                    extra = {
                        
                        func = function()
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.handsizevarE).." Hand Limit", colour = G.C.BLUE})
                            
                            G.hand:change_size(card.ability.extra.handsizevarE)
                            return true
                        end,
                        colour = G.C.WHITE
                    }
                }
            end
        end
        if context.selling_self  then
            return {
                
                func = function()
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(card.ability.extra.handsizevarE).." Hand Limit", colour = G.C.BLUE})
                    
                    G.hand:change_size(-card.ability.extra.handsizevarE)
                    return true
                end
            }
        end
    end,
    
    add_to_deck = function(self, card, from_debuff)
        G.hand:change_size(card.ability.extra.handsizevarE)
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        G.hand:change_size(-card.ability.extra.handsizevarE)
    end
}