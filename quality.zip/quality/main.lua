SMODS.Atlas({
    key = "modicon", 
    path = "ModIcon.png", 
    px = 34,
    py = 34,
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "balatro", 
    path = "balatro.png", 
    px = 333,
    py = 216,
    prefix_config = { key = false },
    atlas_table = "ASSET_ATLAS"
})


SMODS.Atlas({
    key = "CustomJokers", 
    path = "CustomJokers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomDecks", 
    path = "CustomDecks.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

local NFS = require("nativefs")
to_big = to_big or function(a) return a end
lenient_bignum = lenient_bignum or function(a) return a end
-- this function is used to load everything within a folder.-- Jokerforge doesnt use it because it doesnt make loading order easy
local function load_folder(path)
    local files = NFS.getDirectoryItemsInfo(mod_path .. "/" .. path)
    for i = 1, #files do
        local file_name = files[i].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file(path .. file_name))()
        end
    end
end
-- load the jokers
if true then
    assert(SMODS.load_file("jokers/jokerU.lua"))()
    assert(SMODS.load_file("jokers/jokerR.lua"))()
    assert(SMODS.load_file("jokers/jokerE.lua"))()
    assert(SMODS.load_file("jokers/jokerL.lua"))()
    assert(SMODS.load_file("jokers/greedyjokerU.lua"))()
    assert(SMODS.load_file("jokers/greedyjokerR.lua"))()
    assert(SMODS.load_file("jokers/greedyjokerE.lua"))()
    assert(SMODS.load_file("jokers/greedyjokerL.lua"))()
    assert(SMODS.load_file("jokers/lustyjokerU.lua"))()
    assert(SMODS.load_file("jokers/lustyjokerR.lua"))()
    assert(SMODS.load_file("jokers/lustyjokerE.lua"))()
    assert(SMODS.load_file("jokers/lustyjokerL.lua"))()
    assert(SMODS.load_file("jokers/wrathfuljokerU.lua"))()
    assert(SMODS.load_file("jokers/wrathfuljokerR.lua"))()
    assert(SMODS.load_file("jokers/wrathfuljokerE.lua"))()
    assert(SMODS.load_file("jokers/wrathfuljokerL.lua"))()
    assert(SMODS.load_file("jokers/gluttonousjokerU.lua"))()
    assert(SMODS.load_file("jokers/gluttonousjokerR.lua"))()
    assert(SMODS.load_file("jokers/gluttonousjokerE.lua"))()
    assert(SMODS.load_file("jokers/creditcardL.lua"))()
    assert(SMODS.load_file("jokers/creditcardE.lua"))()
    assert(SMODS.load_file("jokers/creditcardR.lua"))()
    assert(SMODS.load_file("jokers/creditcardU.lua"))()
    assert(SMODS.load_file("jokers/gluttonousjokerL.lua"))()
    assert(SMODS.load_file("jokers/baronR.lua"))()
    assert(SMODS.load_file("jokers/baronL.lua"))()
    assert(SMODS.load_file("jokers/baronU.lua"))()
    assert(SMODS.load_file("jokers/baronE.lua"))()
    assert(SMODS.load_file("jokers/goldenjokercopy.lua"))()
    assert(SMODS.load_file("jokers/goldenjokerR.lua"))()
    assert(SMODS.load_file("jokers/goldenjoker.lua"))()
    assert(SMODS.load_file("jokers/goldenjokerL.lua"))()
    assert(SMODS.load_file("jokers/turtlebeanU.lua"))()
    assert(SMODS.load_file("jokers/turtlebeanR.lua"))()
    assert(SMODS.load_file("jokers/turtlebeanE.lua"))()
    assert(SMODS.load_file("jokers/halfjokercopy.lua"))()
    assert(SMODS.load_file("jokers/halfjokercopy3.lua"))()
    assert(SMODS.load_file("jokers/halfjokercopy4.lua"))()
    assert(SMODS.load_file("jokers/halfjokercopy2.lua"))()
    assert(SMODS.load_file("jokers/hangingchadR.lua"))()
    assert(SMODS.load_file("jokers/hangingchadU.lua"))()
    assert(SMODS.load_file("jokers/oopsall6U.lua"))()
    assert(SMODS.load_file("jokers/oopsall6sE.lua"))()
    assert(SMODS.load_file("jokers/oopsall6sR.lua"))()
    assert(SMODS.load_file("jokers/oopsall6sL.lua"))()
    assert(SMODS.load_file("jokers/grosmichelE.lua"))()
    assert(SMODS.load_file("jokers/hikerU.lua"))()
    assert(SMODS.load_file("jokers/hikerR.lua"))()
    assert(SMODS.load_file("jokers/hikerL.lua"))()
    assert(SMODS.load_file("jokers/hikerE.lua"))()
    assert(SMODS.load_file("jokers/smileyfaceU.lua"))()
    assert(SMODS.load_file("jokers/smileyfaceR.lua"))()
    assert(SMODS.load_file("jokers/smileyfaceL.lua"))()
    assert(SMODS.load_file("jokers/smileyfaceE.lua"))()
    assert(SMODS.load_file("jokers/sockandbuskinR.lua"))()
    assert(SMODS.load_file("jokers/sockandbuskinE.lua"))()
    assert(SMODS.load_file("jokers/sockandbuskinL.lua"))()
    assert(SMODS.load_file("jokers/sockandbuskinU.lua"))()
    assert(SMODS.load_file("jokers/photographU.lua"))()
    assert(SMODS.load_file("jokers/photographE.lua"))()
    assert(SMODS.load_file("jokers/photographR.lua"))()
    assert(SMODS.load_file("jokers/photographL.lua"))()
    assert(SMODS.load_file("jokers/mimeL.lua"))()
    assert(SMODS.load_file("jokers/mimeE.lua"))()
    assert(SMODS.load_file("jokers/mimeR.lua"))()
    assert(SMODS.load_file("jokers/abstractjokercopy.lua"))()
    assert(SMODS.load_file("jokers/abstractjokercopy2.lua"))()
    assert(SMODS.load_file("jokers/abstractjokercopy3.lua"))()
    assert(SMODS.load_file("jokers/abstractjokercopy4.lua"))()
    assert(SMODS.load_file("jokers/mimeU.lua"))()
    assert(SMODS.load_file("jokers/bloodstoneR.lua"))()
    assert(SMODS.load_file("jokers/businesscardU.lua"))()
    assert(SMODS.load_file("jokers/businesscardR.lua"))()
    assert(SMODS.load_file("jokers/businesscardE.lua"))()
    assert(SMODS.load_file("jokers/businesscardL.lua"))()
    assert(SMODS.load_file("jokers/grosmichel.lua"))()
    assert(SMODS.load_file("jokers/grosmichelR.lua"))()
    assert(SMODS.load_file("jokers/eggU.lua"))()
    assert(SMODS.load_file("jokers/eggE.lua"))()
    assert(SMODS.load_file("jokers/egg.lua"))()
    assert(SMODS.load_file("jokers/eggR.lua"))()
    assert(SMODS.load_file("jokers/grosmichelL.lua"))()
    assert(SMODS.load_file("jokers/riffraffU.lua"))()
    assert(SMODS.load_file("jokers/riffraffE.lua"))()
    assert(SMODS.load_file("jokers/riffraffR.lua"))()
    assert(SMODS.load_file("jokers/riffraffL.lua"))()
    assert(SMODS.load_file("jokers/blueprintL.lua"))()
    assert(SMODS.load_file("jokers/blueprintE.lua"))()
    assert(SMODS.load_file("jokers/blueprintR.lua"))()
    assert(SMODS.load_file("jokers/blueprintU.lua"))()
    assert(SMODS.load_file("jokers/theidolL.lua"))()
    assert(SMODS.load_file("jokers/bloodstoneL.lua"))()
    assert(SMODS.load_file("jokers/bloodstoneE.lua"))()
    assert(SMODS.load_file("jokers/bloodstoneU.lua"))()
    assert(SMODS.load_file("jokers/spacejokerU.lua"))()
    assert(SMODS.load_file("jokers/spacejokerR.lua"))()
    assert(SMODS.load_file("jokers/spacejoker.lua"))()
    assert(SMODS.load_file("jokers/spacejokerL.lua"))()
    assert(SMODS.load_file("jokers/hangingchadE.lua"))()
    assert(SMODS.load_file("jokers/hangingchadL.lua"))()
    assert(SMODS.load_file("jokers/cavendish.lua"))()
    assert(SMODS.load_file("jokers/cavendish2.lua"))()
    assert(SMODS.load_file("jokers/cavendish3.lua"))()
    assert(SMODS.load_file("jokers/cavendish4.lua"))()
    assert(SMODS.load_file("jokers/turtlebean.lua"))()
end
-- load the decks
if true then
    assert(SMODS.load_file("decks/voilet_deck.lua"))()
end



assert(SMODS.load_file("rarities.lua"))()

SMODS.ObjectType({
    key = "quality_food",
    cards = {
        ["j_gros_michel"] = true,
        ["j_egg"] = true,
        ["j_ice_cream"] = true,
        ["j_cavendish"] = true,
        ["j_turtle_bean"] = true,
        ["j_diet_cola"] = true,
        ["j_popcorn"] = true,
        ["j_ramen"] = true,
        ["j_selzer"] = true
    },
})


SMODS.current_mod.optional_features = function()
    return {
        cardareas = {} 
    }
end