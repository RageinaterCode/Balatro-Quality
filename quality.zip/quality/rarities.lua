SMODS.Rarity {
    key = "mythic",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.015,
    badge_colour = HEX('da9902'),
    loc_txt = {
        name = "Mythic"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "perfected",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.04,
    badge_colour = HEX('af0093'),
    loc_txt = {
        name = "Perfected"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "refined",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.08,
    badge_colour = HEX('0360c1'),
    loc_txt = {
        name = "Refined"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "improved",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.15,
    badge_colour = HEX('008e00'),
    loc_txt = {
        name = "Improved"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}